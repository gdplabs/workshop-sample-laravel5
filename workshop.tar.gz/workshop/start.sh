#!/bin/bash

set -e 

function check_variable(){
    VAR=$1
    
    if [[ -z "${!VAR}" ]]; then
        echo "Missing $VAR variable"
        exit 1
    fi
}

check_variable "DB_HOST"
check_variable "DB_DATABASE"
check_variable "DB_USERNAME"
check_variable "DB_PASSWORD"

sed -i -e 's/DB_HOST=.*/DB_HOST='"$DB_HOST"'/' \
    -e 's/DB_DATABASE=.*/DB_DATABASE='"$DB_DATABASE"'/' \
    -e 's/DB_USERNAME=.*/DB_USERNAME='"$DB_USERNAME"'/' \
    -e 's/DB_PASSWORD=.*/DB_PASSWORD='"$DB_PASSWORD"'/' .env

php artisan migrate
php artisan serve --host=0.0.0.0
